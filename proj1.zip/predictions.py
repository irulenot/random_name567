import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sn
from util import plot_learning_chart
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import AdaBoostClassifier
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.model_selection import cross_validate
from sklearn.model_selection import validation_curve
from sklearn.model_selection import learning_curve
import json


def test_model(model_type, params, param_values, name, data_train, data_test):
    X_train, y_train = data_train[0], data_train[1]
    X_test, y_test = data_test[0], data_test[1]

    results = {'param1': [], 'param2': [], 'estimator': [],
               'train_score': [], 'test_score': [],
               'fit_time': [], 'score_time': []}
    key1, key2 = params.keys()
    for param1 in param_values[0]:
        for param2 in param_values[1]:
            params[key1], params[key2] = param1, param2
            if name == 'Neural Net':
                params['max_iter'] = 1000
            model = model_type(**params)
            metrics = cross_validate(model, X_train, y_train,
                                     return_estimator=True,
                                     return_train_score=True,
                                     error_score=True)
            best_idx = np.argmax(metrics['test_score'])
            for key in metrics.keys():
                results[key].append(metrics[key][best_idx])
            results['param1'].append(param1)
            results['param2'].append(param2)
    results['val_score'] = results.pop('test_score')
    results['test_score'] = []

    for i in range(len(results['estimator'])):
        estimator = results['estimator'][i]
        test_preds = estimator.predict(X_test)
        test_score = accuracy_score(y_test, test_preds)
        results['test_score'].append(test_score)

    return results


def create_learning_curve(results, training_data, name, axes, it):
    X_train, y_train = training_data
    best_idx = np.argmax(results['test_score'])
    best_model = results['estimator'][best_idx]
    plot_learning_chart(best_model, name, X_train, y_train, axes, it)

def create_validation_curve(results, name, axes, it):
    best_idx = np.argmax(results['test_score'])
    if name == 'Neural Net':
        results['param2'] = np.array(results['param2'])[:, 1]
        results['param_values'][1] = np.array(results['param_values'][1])[:, 1]
        results['param_names'].pop(-1)
    best_params = [results['param1'][best_idx], results['param2'][best_idx]]


    all_params = [results['param1'], results['param2']]
    for i in range(2):
        best_param = best_params[i]
        parameter_list = all_params[i]
        if type(parameter_list) != np.ndarray:
            parameter_list = np.array(parameter_list)
        best_param_idx = np.where(best_param == parameter_list)[0]

        other_parameter_list = all_params[i-1]
        if type(other_parameter_list) != np.ndarray:
            other_parameter_list = np.array(other_parameter_list)
        other_params = other_parameter_list[best_param_idx]

        train_score_list = results['train_score']
        if type(train_score_list) != np.ndarray:
            train_score_list = np.array(train_score_list)
        train_scores = train_score_list[best_param_idx]

        val_score_list = results['val_score']
        if type(val_score_list) != np.ndarray:
            val_score_list = np.array(val_score_list)
        val_scores = val_score_list[best_param_idx]

        param_name = results['param_names'][i-1]
        axes[it][i].set_title(name + ' ' + param_name)
        axes[it][i].grid()
        axes[it][i].set_xlabel(param_name)
        axes[it][i].set_ylabel('Accuracy')
        axes[it][i].plot(other_params, train_scores, label='train_scores')
        axes[it][i].plot(other_params, val_scores, label='val_score')
        axes[it][i].legend()

if __name__ == "__main__":
    DATA_PATH = 'data/'
    DATASET_DIRS = ['abalone/', 'stellar/']
    FILE_NAMES = ['abalone.csv', 'stellar.csv']

    for it, file_name in enumerate(FILE_NAMES):
        dataset_name = DATASET_DIRS[it][:-1]
        print('Starting:', dataset_name)
        data = pd.read_csv(DATA_PATH + DATASET_DIRS[it] + file_name)
        for key in data.keys():
            le = LabelEncoder()
            if data[key].dtype == 'object':
                data[key] = le.fit_transform(data[key])
        data.dropna(inplace=True)
        if dataset_name == 'stellar':
            data = data.iloc[:5000]
            Y = pd.DataFrame(data, columns=['class'])
            X = data.drop(columns=['class', 'obj_ID'])
        elif dataset_name == 'abalone':
            drop_list = [25, 2, 29, 26, 1, 24, 27]
            # drop_list = [25, 2, 29, 26, 1, 24, 27, 23, 22, 3, 21, 4] # delete
            data = data[~data['Rings'].isin(drop_list)]
            # data = data.iloc[:500] # delete
            # print(data['Rings'].value_counts())
            Y = pd.DataFrame(data, columns=['Rings'])
            X = data.drop(columns=['Rings'])
        X = StandardScaler().fit(X).transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0, shuffle=True)
        y_train, y_test = y_train.values.ravel(), y_test.values.ravel()

        print('LEN:', str(len(X_train)))
        corrMatrix = data.corr()
        sn.heatmap(corrMatrix)
        plt.savefig(dataset_name + '_corr.png')
        plt.close()

        models = {'Decision Tree': None, 'Neural Net': None,
                  'Boosting': None, 'SVM': None, 'KNN': None}
        fig, axes = plt.subplots(5, 2, figsize=(10, 20))
        for i, name in enumerate(models):
            if name == 'Decision Tree':
                model = DecisionTreeClassifier
                dtree = DecisionTreeClassifier()
                path = dtree.cost_complexity_pruning_path(X_train, y_train)
                params = {'ccp_alpha': None, 'criterion': None}
                param_values = [path.ccp_alphas, ['entropy', 'gini']]
            elif name == 'Neural Net':
                model = MLPClassifier
                params = {'learning_rate_init': None, 'hidden_layer_sizes': None}
                hidden_nodes = X_train.shape[1]
                hidden_layer_sizes = [(hidden_nodes, 1), (hidden_nodes, 2), (hidden_nodes, 3)]
                param_values = [[0.01, 0.001, 0.0001], hidden_layer_sizes]
            elif name == 'Boosting':
                model = GradientBoostingClassifier
                params = {'n_estimators': None, 'max_depth': None}
                param_values = [[5, 25, 100], [1, 2, 3]]
            elif name == 'SVM':
                model = SVC
                params = {'kernel': None, 'C': None}
                param_values = [['linear', 'poly', 'rbf'], [1, 2, 3, 4]]
            elif name == 'KNN':
                model = KNeighborsClassifier
                params = {'n_neighbors': None, 'metric': None}
                param_values = [[1, 2, 3, 4, 5, 6], ['euclidean', 'manhattan', 'chebyshev']]

            models[name] = test_model(model, params, param_values, name,
                                      (X_train, y_train), (X_test, y_test))
            models[name]['param_names'] = list(params.keys())

            create_learning_curve(models[name], (X_train, y_train), name, axes, i)

            file_path = 'results/' + dataset_name + '_' + name + '_results.json'
            file = open(file_path, "w+")
            estimators = models[name].pop('estimator', None)
            file.write(json.dumps(models[name]))
            file.close()

            models[name]['estimator'] = estimators
            models[name]['param_values'] = param_values

        plt.tight_layout()
        plt.savefig(dataset_name + '_learning_curves.png')
        plt.close()

        fig, axes = plt.subplots(5, 2, figsize=(15, 25))
        for i, name in enumerate(models):
            create_validation_curve(models[name], name, axes, i)
        plt.tight_layout()
        plt.savefig(dataset_name + '_validation_curves.png')
        plt.close()

        print('Finished:', dataset_name, '\n')