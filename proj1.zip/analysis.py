import pandas as pd
import numpy as np
import json

DATA_PATH = 'data/'
DATASET_DIRS = ['abalone/', 'stellar/']
FILE_NAMES = ['abalone.csv', 'stellar.csv']

for it, file_name in enumerate(FILE_NAMES):
    dataset_name = DATASET_DIRS[it][:-1]
    data = pd.read_csv(DATA_PATH + DATASET_DIRS[it] + file_name)
    print(dataset_name)
    print('Examples:', len(data))
    print('Features:', len(data.columns))
    print()

    total_model_count = 0
    for name in ['Decision Tree', 'Neural Net', 'Boosting', 'SVM', 'KNN']:
        file_path = 'results/' + dataset_name + '_' + name + '_results.json'
        file = open(file_path)
        results = json.load(file)

        model_count = len(results['param1'])
        total_model_count += len(results['param1'])
        test_scores = np.array(results['test_score'])
        best_idxs = np.where(test_scores == max(test_scores))
        best_results = {}
        for best_idx in best_idxs[0]:
            for key in results.keys():
                if key == 'param_names':
                    continue
                elif key not in best_results:
                    best_results[key] = []
                best_results[key].append(results[key][int(best_idx)])

        print(name)
        print('Model count:', model_count)
        print()
    print('Total model count:', total_model_count)

[0.9573333333333334]