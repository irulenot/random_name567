# ml-gatech

## Repo


## Datasets
1. https://www.kaggle.com/fedesoriano/stellar-classification-dataset-sdss17
2. https://www.kaggle.com/rodolfomendes/abalone-dataset