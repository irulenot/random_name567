import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler
from sklearn.random_projection import GaussianRandomProjection
from sklearn.model_selection import train_test_split
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA, FastICA, TruncatedSVD
from sklearn.metrics import silhouette_score
from scipy.stats import kurtosis
import matplotlib.pyplot as plt
from numpy.linalg import eigh
from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier
import json
import time

def test_model(X_train, X_test, y_train, y_test, best_nn_params, id):
    best_nn_params['hidden_layer_sizes'] = [X_train.shape[1], best_nn_params['hidden_layer_sizes'][1]]
    start_time = time.time()
    model = MLPClassifier(**best_nn_params).fit(X_train, y_train)
    total_time = time.time() - start_time
    pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, pred)
    f = open('best-2.txt', 'a+')
    f.write(id + ': ' + str(round(total_time, 2)) + ' ' + str(round(accuracy*100, 2)) + '\n')
    f.close()
    print(id + ': ' + str(round(total_time, 2)) + ' ' + str(round(accuracy*100, 2)) + '\n')

if __name__ == "__main__":
    DATA_PATH = 'data/'
    DATASET_DIRS = ['abalone/', 'stellar/']
    FILE_NAMES = ['abalone.csv', 'stellar.csv']

    for it, file_name in enumerate(FILE_NAMES):
        dataset_name = DATASET_DIRS[it][:-1]
        if dataset_name == 'abalone':
            continue
        data = pd.read_csv(DATA_PATH + DATASET_DIRS[it] + file_name)
        for key in data.keys():
            le = LabelEncoder()
            if data[key].dtype == 'object':
                data[key] = le.fit_transform(data[key])
        data.dropna(inplace=True)
        if dataset_name == 'stellar':
            data = data.iloc[:5000]
            Y = pd.DataFrame(data, columns=['class'])
            X = data.drop(columns=['class', 'obj_ID'])
        elif dataset_name == 'abalone':
            drop_list = [25, 2, 29, 26, 1, 24, 27]
            data = data[~data['Rings'].isin(drop_list)]
            Y = pd.DataFrame(data, columns=['Rings'])
            X = data.drop(columns=['Rings'])
        X = StandardScaler().fit(X).transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0, shuffle=True)
        y_train, y_test = y_train.values.ravel(), y_test.values.ravel()

        with open('results/' + dataset_name + '_Neural Net_results.json', 'r') as file:
            nn_results = json.load(file)
        best_idx = np.argmax(nn_results['test_score'])
        best_nn_params = {nn_results['param_names'][0]: nn_results['param1'][best_idx],
                          nn_results['param_names'][1]: nn_results['param2'][best_idx],
                          'random_state': 1}

        # NORMAL
        start_time = time.time()
        model = MLPClassifier(**best_nn_params).fit(X_train, y_train)
        total_time = time.time() - start_time
        pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, pred)
        f = open('best-2.txt', 'a+')
        f.write('vanilla' + ': ' + str(round(total_time, 2)) + ' ' + str(round(accuracy*100, 2)) + '\n')
        f.close()
        print('vanilla' + ': ' + str(round(total_time, 2)) + ' ' + str(round(accuracy*100, 2)) + '\n')

        # PCA + CLUSTERING
        scaler = MinMaxScaler()
        scaled_X_train = scaler.fit_transform(X_train)
        scaled_X_test = scaler.fit_transform(X_test)
        pca = PCA(n_components=0.95, random_state=0).fit(scaled_X_train)
        pca_X_train = pca.transform(scaled_X_train)
        pca_X_test = pca.transform(scaled_X_test)
        kmeans = KMeans(n_clusters=48, random_state=0).fit(pca_X_train)
        kmeans_X_train = kmeans.transform(pca_X_train)
        kmeans_X_test = kmeans.transform(pca_X_test)
        em = GaussianMixture(n_components=43, random_state=0).fit(pca_X_train)
        em_X_train = em.predict_proba(pca_X_train)
        em_X_test = em.predict_proba(pca_X_test)
        test_model(pca_X_train, pca_X_test, y_train, y_test, best_nn_params, 'pca')
        test_model(kmeans_X_train, kmeans_X_test, y_train, y_test, best_nn_params, 'pca+kmeans')
        test_model(em_X_train, em_X_test, y_train, y_test, best_nn_params, 'pca+em')

        # ICA + CLUSTERING
        ica = FastICA(n_components=5, random_state=0)
        ica_X_train = ica.fit_transform(X_train)
        ica_X_test = ica.transform(X_test)
        kmeans = KMeans(n_clusters=46, random_state=0).fit(ica_X_train)
        kmeans_X_train = kmeans.transform(ica_X_train)
        kmeans_X_test = kmeans.transform(ica_X_test)
        em = GaussianMixture(n_components=5, random_state=0).fit(ica_X_train)
        em_X_train = em.predict_proba(ica_X_train)
        em_X_test = em.predict_proba(ica_X_test)
        test_model(ica_X_train, ica_X_test, y_train, y_test, best_nn_params, 'ica')
        test_model(kmeans_X_train, kmeans_X_test, y_train, y_test, best_nn_params, 'ica+kmeans')
        test_model(em_X_train, em_X_test, y_train, y_test, best_nn_params, 'ica+em')

        # RP + CLUSTERING
        rp = GaussianRandomProjection(n_components=5, random_state=0)
        rp_X_train = rp.fit_transform(scaled_X_train)
        rp_X_test = rp.fit_transform(scaled_X_test)
        kmeans = KMeans(n_clusters=48, random_state=0).fit(rp_X_train)
        kmeans_X_train = kmeans.transform(rp_X_train)
        kmeans_X_test = kmeans.transform(rp_X_test)
        em = GaussianMixture(n_components=7, random_state=0).fit(rp_X_train)
        em_X_train = em.predict_proba(rp_X_train)
        em_X_test = em.predict_proba(rp_X_test)
        test_model(rp_X_train, rp_X_test, y_train, y_test, best_nn_params, 'rp')
        test_model(kmeans_X_train, kmeans_X_test, y_train, y_test, best_nn_params, 'rp+kmeans')
        test_model(em_X_train, em_X_test, y_train, y_test, best_nn_params, 'rp+em')

        # SVD + CLUSTERING
        svd = TruncatedSVD(n_components=9, random_state=0).fit(X_train)
        svd_X_train = svd.transform(X_train)
        svd_X_test = svd.transform(X_test)
        kmeans = KMeans(n_clusters=46, random_state=0).fit(svd_X_train)
        kmeans_X_train = kmeans.transform(svd_X_train)
        kmeans_X_test = kmeans.transform(svd_X_test)
        em = GaussianMixture(n_components=23, random_state=0).fit(svd_X_train)
        em_X_train = em.predict_proba(svd_X_train)
        em_X_test = em.predict_proba(svd_X_test)
        test_model(svd_X_train, svd_X_test, y_train, y_test, best_nn_params, 'svd')
        test_model(kmeans_X_train, kmeans_X_test, y_train, y_test, best_nn_params, 'svd+kmeans')
        test_model(em_X_train, em_X_test, y_train, y_test, best_nn_params, 'svd+em')