import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler
from sklearn.random_projection import GaussianRandomProjection
from sklearn.model_selection import train_test_split
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA, FastICA, TruncatedSVD
from sklearn.metrics import silhouette_score
from scipy.stats import kurtosis
import matplotlib.pyplot as plt
from numpy.linalg import eigh


def kmeans_analysis(X, run_name):
    # function returns WSS score for k values from 1 to kmax
    def kmeans_WSS(points, kmax):
        sse = []
        for k in range(2, kmax + 1):
            kmeans = KMeans(n_clusters=k, random_state=0).fit(points)
            centroids = kmeans.cluster_centers_
            pred_clusters = kmeans.predict(points)
            curr_sse = 0

            # calculate square of Euclidean distance of each point from its cluster center and add to current WSS
            for i in range(len(points)):
                curr_center = centroids[pred_clusters[i]]
                curr_sse += (points[i, 0] - curr_center[0]) ** 2 + (points[i, 1] - curr_center[1]) ** 2

            sse.append(curr_sse)
        return sse
    def kmeans_SIL(x, kmax):
        sil = []
        # dissimilarity would not be defined for a single cluster, thus, minimum number of clusters should be 2
        for k in range(2, kmax + 1):
            kmeans = KMeans(n_clusters=k, random_state=0).fit(x)
            labels = kmeans.labels_
            sil.append(silhouette_score(x, labels, metric='euclidean'))
        return sil

    sse = kmeans_WSS(X, 50)
    sil = kmeans_SIL(X, 50)

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(15, 5))
    ax[0].plot(range(2, len(sse)+2), sse)
    ax[0].set_title('Within-Cluster-Sum of Squared Errors')
    ax[0].set_xlabel('K')
    ax[0].set_ylabel('Error')
    ax[1].plot(range(2, len(sil)+2), sil)
    ax[1].set_title('Silhouette Scores')
    ax[1].set_xlabel('K')
    ax[1].set_ylabel('Score')
    plt.savefig('graphs/kmeans-' + run_name + '.png')
    plt.clf()

    sse_normed = sse / max(sse)
    sil_normed = sil / max(sil)
    combination = abs(sse_normed - 1) + sil_normed
    best_k = np.argmax(combination)
    print('Best k for run', run_name, ': ', best_k)
    f = open('best-1.txt', 'a+')
    f.write('kmeans-' + run_name + ': ' + str(best_k) + '\n')
    f.close()
    return KMeans(n_clusters=best_k, random_state=0).fit(X)

def em_analysis(X, run_name):
    def calculate_SIL_EM(x, c_max):
        n_clusters = np.arange(2, c_max)
        sils = []
        for n in n_clusters:
            gmm = GaussianMixture(n_components=n, random_state=0).fit(x)
            labels = gmm.predict(x)
            sil = silhouette_score(x, labels, metric='euclidean')
            sils.append(sil)
        return sils
    def calculate_BIC(x, c_max):
        n_clusters = np.arange(2, c_max)
        bics = []
        for n in n_clusters:
            gmm = GaussianMixture(n_components=n, random_state=0).fit(x)
            bics.append(gmm.bic(x))
        return bics

    sils = calculate_SIL_EM(X, 50)
    bics = calculate_BIC(X, 50)

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(15, 5))
    ax[0].plot(range(2, len(sils)+2), sils)
    ax[0].set_title('Silhouette Scores')
    ax[0].set_xlabel('Components')
    ax[0].set_ylabel('Score')
    ax[1].plot(range(2, len(bics)+2), bics)
    ax[1].set_title('Bayesian information criterion')
    ax[1].set_xlabel('Components')
    ax[1].set_ylabel('Value')
    plt.savefig('graphs/em-' + run_name + '.png')
    plt.clf()

    sils_normed = sils / max(sils)
    bics_normed = (bics - min(bics)) / max(bics - min(bics))
    combination = sils_normed + abs(bics_normed - 1)
    best_c = np.argmax(combination)
    print('Best c for run', run_name, ': ', best_c)
    f = open('best-1.txt', 'a+')
    f.write('em-' + run_name + ': ' + str(best_c) + '\n')
    f.close()
    return GaussianMixture(n_components=best_c, random_state=0).fit(X)

if __name__ == "__main__":
    DATA_PATH = 'data/'
    DATASET_DIRS = ['abalone/', 'stellar/']
    FILE_NAMES = ['abalone.csv', 'stellar.csv']

    for it, file_name in enumerate(FILE_NAMES):
        dataset_name = DATASET_DIRS[it][:-1]
        data = pd.read_csv(DATA_PATH + DATASET_DIRS[it] + file_name)
        for key in data.keys():
            le = LabelEncoder()
            if data[key].dtype == 'object':
                data[key] = le.fit_transform(data[key])
        data.dropna(inplace=True)
        if dataset_name == 'stellar':
            print(len(np.unique(data['class'])))

            data = data.iloc[:5000]
            Y = pd.DataFrame(data, columns=['class'])
            X = data.drop(columns=['class', 'obj_ID'])
        elif dataset_name == 'abalone':
            print(len(np.unique(data.Rings)))
            drop_list = [25, 2, 29, 26, 1, 24, 27]
            data = data[~data['Rings'].isin(drop_list)]
            Y = pd.DataFrame(data, columns=['Rings'])
            X = data.drop(columns=['Rings'])
        X = StandardScaler().fit(X).transform(X)
        X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0, shuffle=True)
        y_train, y_test = y_train.values.ravel(), y_test.values.ravel()

        scaler = MinMaxScaler()
        scaled_X_train = scaler.fit_transform(X_train)
        pca = PCA(n_components=0.95, random_state=0).fit(scaled_X_train)
        pca_X_train = pca.transform(scaled_X_train)
        kmeans0 = kmeans_analysis(pca_X_train, dataset_name + '-pca-1')
        em0 = em_analysis(pca_X_train, dataset_name + '-pca-1')

        if dataset_name == 'abalone':
            best_ica_c = 2
        else:
            best_ica_c = 5
        ica = FastICA(n_components=best_ica_c, random_state=0)
        ica_X_train = ica.fit_transform(X_train)
        kmeans0 = kmeans_analysis(ica_X_train, dataset_name + '-ica-1')
        em0 = em_analysis(ica_X_train, dataset_name + '-ica-1')

        if dataset_name == 'abalone':
            best_rp_c = 2
        else:
            best_rp_c = 5
            continue # Bugs, but will generate graph if don't skip
        scaler = MinMaxScaler()
        scaled_X_train = scaler.fit_transform(X_train)
        rp = GaussianRandomProjection(n_components=best_rp_c, random_state=0)
        rp_X_train = rp.fit_transform(scaled_X_train)
        kmeans0 = kmeans_analysis(rp_X_train, dataset_name + '-rp-1')
        em0 = em_analysis(rp_X_train, dataset_name + '-rp-1')

        if dataset_name == 'abalone':
            best_svd_c = 3
        else:
            best_svd_c = 9
        svd = TruncatedSVD(n_components=best_svd_c, random_state=0).fit(X_train)
        svd_X_train = svd.transform(X_train)
        kmeans0 = kmeans_analysis(svd_X_train, dataset_name + '-svd-1')
        em0 = em_analysis(svd_X_train, dataset_name + '-svd-1')