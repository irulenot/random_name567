import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle

if __name__ == "__main__":
    ttt, fff = True, False
    load, save = fff, ttt

    problem = 'forest'
    algorithm = 'policy_iteration'
    combined = problem + '_' + algorithm
    if load:
        with open('meta/' + combined + '_stats.pkl', 'rb') as f:
            run_stats = pickle.load(f)
    else:
        S = 10000
        P, R = example.forest(S=S)
        alg = mdp.PolicyIteration(P, R, 0.96)
        run_stats = alg.run()
        if save:
            with open('meta/' + combined + '_stats.pkl', 'wb') as f:
                pickle.dump(run_stats, f)

    Y_names = ['Reward', 'Mean V', 'Max V', 'Time']
    Ys = [[], [], [], []]
    X_names = ['Iterations']
    Xs = [[]]
    for i, stats in enumerate(run_stats):
        Ys[0].append(stats[Y_names[0]])
        Ys[1].append(stats[Y_names[1]])
        Ys[2].append(stats[Y_names[2]])
        Ys[3].append(stats['Time'])
        Xs[0].append(i)

    fig, axs = plt.subplots(2, 2)
    fig.suptitle(combined + ' ' + str(S))
    for x in range(2):
        for y in range(2):
            axs[x, y].plot(Xs[0], Ys[y+x*2])
            axs[x, y].set_xlabel(X_names[0])
            axs[x, y].set_ylabel(Y_names[y+x*2])
        fig.tight_layout()
    fig.savefig('results/' + combined + '.png')