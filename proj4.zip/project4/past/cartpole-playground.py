import numpy as np
import gym
import time
import math

env = gym.make("CartPole-v1")
env.reset()
one = True
while True:
    env.render()
    if one:
        new_state, reward, done, _ = env.step(1)
        print(new_state)
        one = False
    else:
        new_state, reward, done, _ = env.step(0)
        print(new_state)
        one = True

