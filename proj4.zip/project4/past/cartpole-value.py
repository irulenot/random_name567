import gym
import numpy as np
from tqdm import tqdm
import os.path

def get_discrete_state(state):
    np_array_win_size = np.array([0.25, 0.25, 0.01, 0.1])
    discrete_state = state/np_array_win_size + np.array([15,10,1,10])
    for i, state in enumerate(discrete_state):
        if state < 0:
            discrete_state[i] = 0
        elif state > 49:
            discrete_state[i] = 49
    return tuple(discrete_state.astype('int'))

def get_continuous_state(state):
    np_array_win_size = np.array([0.25, 0.25, 0.01, 0.1])
    continuous_state = (state - np.array([15, 10, 1, 10])) * np_array_win_size
    return continuous_state

def value_iteration(env, nS, lmbda=0.9):
    # if os.path.isfile('meta/cartpol-value-stateValue.npy'):
    #     return np.load('meta/cartpol-value-stateValue.npy')

    env.nS = nS
    env.nA = 2
    stateValue = np.random.uniform(low=0, high=1, size=(Observation))
    newStateValue = stateValue.copy()
    for x in tqdm(range(stateValue.shape[0])):
        for y in range(stateValue.shape[1]):
            for z in range(stateValue.shape[2]):
                for r in range(stateValue.shape[3]):
                    action_values = []
                    state = [x, y, z, r]
                    for action in range(env.nA):
                        env.reset()
                        env.env.env.state = get_continuous_state(state)
                        state_value = 0
                        next_state, reward, done, _ = env.step(action)
                        if done:
                            reward = -500
                        next_state = get_discrete_state(next_state)
                        state_action_value = 1 * (reward + lmbda * stateValue[next_state])
                        state_value += state_action_value
                        action_values.append(state_value)  # the value of each action
                        best_action = np.argmax(np.asarray(action_values))  # choose the action which gives the maximum value
                        newStateValue[x][y][z][r] = action_values[best_action]  # update the value of the state

    # with open('meta/cartpol-value-stateValue.npy', 'wb') as f:
    #     np.save(f, newStateValue)
    return newStateValue


def get_policy(env, stateValue, nS, lmbda=0.9):
    # if os.path.isfile('meta/cartpol-value-policy.npy'):
    #     return np.load('meta/cartpol-value-policy.npy')

    env.nS = nS
    env.nA = 2
    policy = np.random.uniform(low=0, high=1, size=(Observation))
    for x in tqdm(range(stateValue.shape[0])):
        for y in range(stateValue.shape[1]):
            for z in range(stateValue.shape[2]):
                for r in range(stateValue.shape[3]):
                    action_values = []
                    env.reset()
                    state = [x, y, z, r]
                    env.state = get_continuous_state(state)
                    for action in range(env.nA):
                        action_value = 0
                        next_state, reward, done, _ = env.step(action)
                        next_state = get_discrete_state(next_state)
                        if done:
                            reward = -500
                        action_value += 1 * (reward + lmbda * stateValue[next_state])
                        action_values.append(action_value)
                    best_action = np.argmax(np.asarray(action_values))
                    policy[x][y][z][r] = best_action

    # with open('meta/cartpol-value-policy.npy', 'wb') as f:
    #     np.save(f, policy)
    return policy


def get_score(env, policy, episodes=1000):
    # if os.path.isfile('results/cartpol-value.txt'):
    #     return

    wins, losses = 0, 0
    steps_list = []
    for episode in range(episodes):
        observation = env.reset()
        steps = 0
        while True:
            # env.render()
            observation = get_discrete_state(observation)
            action = policy[observation]
            observation, reward, done, _ = env.step(int(action))
            steps += 1
            if done and steps >= 500:
                steps_list.append(steps)
                wins += 1
                break
            elif done:
                steps_list.append(steps)
                losses += 1
                break
    with open('../results/cartpol-value.txt', 'w') as f:
        f.write('Avg steps ' + str(np.average(steps_list)))
        f.write('\n')
        f.write('Win ratio ' + str(wins/(wins+losses)))

if __name__ == "__main__":
    env = gym.make("CartPole-v1")
    env.reset()
    Observation = [30, 30, 50, 50]
    nS = np.prod(Observation)

    stateValues = value_iteration(env, nS)
    env.reset()
    policy = get_policy(env, stateValues, nS)
    env.reset()
    get_score(env, policy, episodes=1000)
