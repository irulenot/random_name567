import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd
import seaborn as sns


if __name__ == "__main__":
    mode = ['save', 'load']
    m = 0

    S = 10000
    P, R = example.forest(S=S)
    algs, combined_names = [], []
    algs.append(mdp.PolicyIteration(P, R, 0.96))
    algs.append(mdp.ValueIteration(P, R, 0.96))
    algs.append(mdp.QLearning(P, R, 0.96, n_iter=1000000))
    problem = 'forest-' + str(S)
    combined_names.append(problem + '_' + 'policy_iteration')
    combined_names.append(problem + '_' + 'value_iteration')
    combined_names.append(problem + '_' + 'qlearner')

    for i, alg in tqdm(enumerate(algs)):
        if mode[m] == 'save':
            run_stats = alg.run()
            with open('meta/' + combined_names[i] + '_stats.pkl', 'wb') as f:
                pickle.dump(run_stats, f)
        else:
            with open('meta/' + combined_names[i] + '_stats.pkl', 'rb') as f:
                run_stats = pickle.load(f)

        df = pd.DataFrame(run_stats)
        alg_P = df['Policy'].iloc[-1].reshape(100, 100)
        sns.heatmap(alg_P, linewidth=0.5)
        title = combined_names[i] + '_policy'
        plt.title(title)
        plt.savefig('results/' + title + '.png')
        plt.close()


