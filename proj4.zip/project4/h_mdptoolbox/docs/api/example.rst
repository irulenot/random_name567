.. automodule:: mdptoolbox.example
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
