.. automodule:: mdptoolbox.mdp
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
