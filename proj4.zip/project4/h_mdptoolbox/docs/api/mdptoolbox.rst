.. automodule:: mdptoolbox
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
