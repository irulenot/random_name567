.. automodule:: mdptoolbox.util
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
