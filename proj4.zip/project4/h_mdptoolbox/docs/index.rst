.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   api/mdptoolbox
   api/mdp
   api/util
   api/example

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

