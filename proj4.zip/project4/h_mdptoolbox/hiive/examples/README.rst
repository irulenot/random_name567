Python MDP Toolbox Examples
===========================