import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd

if __name__ == "__main__":
    mode = ['save', 'load']
    m = 1

    S = 10000
    P, R = example.forest(S=S)
    algs, combined_names = [], []
    algs.append(mdp.PolicyIteration(P, R, 0.96))
    algs.append(mdp.ValueIteration(P, R, 0.96))
    algs.append(mdp.QLearning(P, R, 0.96, n_iter=1000000))
    problem = 'forest'
    combined_names.append(problem + '_' + 'policy_iteration')
    combined_names.append(problem + '_' + 'value_iteration')
    combined_names.append(problem + '_' + 'qlearner')

    for i, alg in tqdm(enumerate(algs)):
        if mode[m] == 'save':
            run_stats = alg.run()
            with open('meta/' + combined_names[i] + '_stats.pkl', 'wb') as f:
                pickle.dump(run_stats, f)
        else:
            with open('meta/' + combined_names[i] + '_stats.pkl', 'rb') as f:
                run_stats = pickle.load(f)

        Y_names = ['Mean V', 'Max V', 'Time']
        Ys = [[], [], []]
        X_names = ['Iteration']
        Xs = [[]]
        for it, stats in enumerate(run_stats):
            Ys[0].append(stats[Y_names[0]])
            Ys[1].append(stats[Y_names[1]])
            Ys[2].append(stats[Y_names[2]])
            Xs[0].append(stats[X_names[0]])

        fig, axs = plt.subplots(3)
        fig.suptitle(combined_names[i] + ' ' + str(S))
        for y in range(3):
            axs[y].plot(Xs[0], Ys[y])
            axs[y].set_xlabel(X_names[0])
            axs[y].set_ylabel(Y_names[y])
        fig.tight_layout()
        fig.savefig('results/' + combined_names[i] + '.png')

        df = pd.DataFrame(run_stats)
        total_time = sum(df['Time'])
        best_performance = max(df['Mean V'])
        names = ['PL', 'VL', 'QL']
        print(names[i], 'total_time', total_time, 'best_performance', best_performance)