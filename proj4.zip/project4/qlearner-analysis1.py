import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd

# gamma,
#
#                  alpha=0.1, alpha_decay=0.99, alpha_min=0.001,
#                  epsilon=1.0, epsilon_min=0.1, epsilon_decay=0.99,
#                  n_iter=10000, skip_check=False, iter_callback=None,
#                  run_stat_frequency=None):

if __name__ == "__main__":
    mode = ['save', 'load']
    m = 0

    S = 10
    P, R = example.forest(S=S)
    gamma = 0.96
    alphas = [0.001, 0.1, 1]
    alpha_decays = [0.99, 0.5, 0.1]
    alpha_mins = [0.001, 0.01, 0.1]
    best_param = (None, None, None)
    best_performance = 0
    for alpha in alphas:
        for alpha_decay in alpha_decays:
            for alpha_min in alpha_mins:
                param = str(alpha) + '_' + str(alpha_decay) + '_' + str(alpha_min)
                alg = mdp.QLearning(P, R, gamma, alpha=alpha, alpha_decay=alpha_decay, alpha_min=alpha_min, n_iter=10000)
                problem = 'forest' + str(S)
                combined_name = problem + '_' + 'qlearner_' + param

                if mode[m] == 'save':
                    run_stats = alg.run()
                    with open('meta/' + combined_name + '_stats.pkl', 'wb') as f:
                        pickle.dump(run_stats, f)
                else:
                    with open('meta/' + combined_name + '_stats.pkl', 'rb') as f:
                        run_stats = pickle.load(f)

                Y_names = ['Mean V', 'Max V', 'Time']
                Ys = [[], [], []]
                X_names = ['Iteration']
                Xs = [[]]
                for it, stats in enumerate(run_stats):
                    Ys[0].append(stats[Y_names[0]])
                    Ys[1].append(stats[Y_names[1]])
                    Ys[2].append(stats[Y_names[2]])
                    Xs[0].append(stats[X_names[0]])

                fig, axs = plt.subplots(3)
                fig.suptitle(combined_name + ' ' + str(S))
                for y in range(3):
                    axs[y].plot(Xs[0], Ys[y])
                    axs[y].set_xlabel(X_names[0])
                    axs[y].set_ylabel(Y_names[y])
                fig.tight_layout()
                fig.savefig('results/' + combined_name + '.png')

                df = pd.DataFrame(run_stats)
                total_time = sum(df['Time'])
                performance = max(df['Mean V'])
                names = ['PL', 'VL', 'QL']
                print(param, 'total_time', total_time, 'best_performance', performance)

                if best_performance < performance:
                    best_param = param
                    best_performance = performance

    print(best_param)
    print(best_performance)