import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd

if __name__ == "__main__":
    mode = ['save', 'load']
    m = 0

    states = [10, 100, 1000, 10000]
    for state in states:
        P, R = example.forest(S=state)
        algs, combined_names = [], []
        algs.append(mdp.PolicyIteration(P, R, 0.96))
        algs.append(mdp.ValueIteration(P, R, 0.96))
        problem = 'forest-' + str(state)
        combined_names.append(problem + '_' + 'policy_iteration')
        combined_names.append(problem + '_' + 'value_iteration')
        combined_names.append(problem + '_' + 'qlearner')

        for i, alg in tqdm(enumerate(algs)):
            if mode[m] == 'save':
                run_stats = alg.run()
                with open('meta/' + combined_names[i] + '_stats.pkl', 'wb') as f:
                    pickle.dump(run_stats, f)
            else:
                with open('meta/' + combined_names[i] + '_stats.pkl', 'rb') as f:
                    run_stats = pickle.load(f)

            Y_names = ['Mean V']
            Ys = [[], [], []]
            X_names = ['Iteration']
            Xs = [[]]
            for it, stats in enumerate(run_stats):
                Ys[0].append(stats[Y_names[0]])
                Xs[0].append(stats[X_names[0]])

            plt.title(combined_names[i] + ' ' + str(state))
            plt.plot(Xs[0], Ys[0])
            plt.xlabel(X_names[0])
            plt.ylabel(Y_names[0])
            plt.savefig('results/' + combined_names[i] + '.png')
            plt.close()

            df = pd.DataFrame(run_stats)
            total_time = sum(df['Time'])
            best_performance = max(df['Mean V'])
            names = ['PL', 'VL', 'QL']
            print(state, names[i], 'total_time', total_time, 'best_performance', best_performance)