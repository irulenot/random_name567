import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd
import seaborn as sns

if __name__ == "__main__":
    FM_P, FM_R = example.forest(S=10000)
    env = openai2.OpenAI_MDPToolbox("FrozenLake-v1", map_name="8x8")
    FL_P, FL_R = env.P, env.R

    for i, P in enumerate(FM_P):
        sns.heatmap(P)
        title = 'forest-10000_action' + str(i) + '_heatmap'
        plt.title(title)
        plt.savefig('results/' + title + '.png')
        plt.close()
    for i, P in enumerate(FL_P):
        sns.heatmap(P)
        title = 'frozenlake-8x8_action' + str(i) + '_heatmap'
        plt.title(title)
        plt.savefig('results/' + title + '.png')
        plt.close()