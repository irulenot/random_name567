Link: https://github.com/irulenot/random_name567

Run each python file in the top directory to generate all results.