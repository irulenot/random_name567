import h_mdptoolbox.hiive.mdptoolbox.example as example
import h_mdptoolbox.hiive.mdptoolbox.openai as openai2
import h_mdptoolbox.hiive.mdptoolbox.mdp as mdp
import matplotlib.pyplot as plt
import pickle
from tqdm import tqdm
import pandas as pd
import seaborn as sns


if __name__ == "__main__":
    mode = ['save', 'load']
    m = 0

    S = "8x8"
    env = openai2.OpenAI_MDPToolbox("FrozenLake-v1", map_name=S)
    algs, combined_names = [], []
    algs.append(mdp.PolicyIteration(env.P, env.R, 0.96, max_iter=8))
    algs.append(mdp.ValueIteration(env.P, env.R, 0.96))
    algs.append(mdp.QLearning(env.P, env.R, 0.96, n_iter=1000000))
    problem = 'frozenlake-' + S
    combined_names.append(problem + '_' + 'policy_iteration')
    combined_names.append(problem + '_' + 'value_iteration')
    combined_names.append(problem + '_' + 'qlearner')

    for i, alg in tqdm(enumerate(algs)):
        if mode[m] == 'save':
            run_stats = alg.run()
            with open('meta/' + combined_names[i] + '_stats.pkl', 'wb') as f:
                pickle.dump(run_stats, f)
        else:
            with open('meta/' + combined_names[i] + '_stats.pkl', 'rb') as f:
                run_stats = pickle.load(f)

        df = pd.DataFrame(run_stats)
        alg_P = df['Policy'].iloc[-1].reshape(8, 8)
        sns.heatmap(alg_P, linewidth=0.5)
        title = combined_names[i] + '_policy'
        plt.title(title)
        plt.savefig('results/' + title + '.png')
        plt.close()


