import mlrose_hiive as mlrose
import matplotlib.pyplot as plt
import time

if __name__ == "__main__":
    algorithm = mlrose.genetic_alg
    fitness = mlrose.OneMax()
    algorithm_name = 'genetic_alg'
    fitness_name = 'OneMax'
    algorithm_params = {'mutation_prob': [0.01, 0.25, 0.5, 0.75, 1],
                        'pop_size': [2, 10, 100, 1000]}
    logs = {fitness_name: {}}

    size = 1000
    max_iterations = 125
    problem = mlrose.DiscreteOpt(length=size, fitness_fn=fitness, maximize=True)
    fitness_log = logs[fitness_name]
    for param, values in algorithm_params.items():
        fitness_log[param] = {}
        param_log = fitness_log[param]
        for value in values:
            parameter = {'problem': problem, 'random_state': 1, param: value}
            start_time = time.time()
            best_state, best_fitness, _ = algorithm(**parameter)
            total_time = time.time() - start_time
            param_log[value] = {'fitness': str(best_fitness),
                                'time': total_time}
            print(param_log[value])

    for problem, algorithms in logs.items():
        param_scores = {}
        param_times = {}
        param_names = list(algorithm_params.keys())
        param_idx = 0
        for algorithm, param_values in algorithms.items():
            param_scores[param_names[param_idx]] = []
            param_times[param_names[param_idx]] = []
            for param_values, values in param_values.items():
                score, time = values.values()
                param_scores[param_names[param_idx]].append(score)
                param_times[param_names[param_idx]].append(time)
            param_idx += 1

    fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(15, 5))
    ax_idx = 0
    for name, values in algorithm_params.items():
        ax[ax_idx][0].plot(values, param_scores[name])
        ax[ax_idx][0].set_title(name + ' Scores')
        ax[ax_idx][0].set_xlabel(name)
        ax[ax_idx][0].set_ylabel('Fitness Score')
        ax[ax_idx][0].legend()

        ax[ax_idx][1].plot(values, param_times[name])
        ax[ax_idx][1].set_title(name + ' Times')
        ax[ax_idx][1].set_xlabel(name)
        ax[ax_idx][1].set_ylabel('Time')
        ax[ax_idx][1].legend()
        ax_idx+= 1

    fig.tight_layout()
    plt.savefig('part1_graphs/' + algorithm_name + '_subplots.png')
    plt.clf()
