import mlrose_hiive as mlrose
from tqdm import tqdm

import numpy as np
import random
import json
import time

# 3 Optimization Problems
# 1: Genetic algorithm (TSP)
# 2: Simulated annealing (Continuous Peaks)
# 3: MIMIC (FlipFlop)

# Measurements
# Problem size
# Time to run
# Iterations
# Fitness score

if __name__ == "__main__":
    algorithms = [mlrose.random_hill_climb, mlrose.simulated_annealing,
                  mlrose.mimic, mlrose.genetic_alg]
    fitnesses = [mlrose.OneMax(), mlrose.FlipFlop(), mlrose.SixPeaks(),
                 mlrose.ContinuousPeaks(), mlrose.Queens()]
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'mimic', 'genetic_alg']
    fitness_names = ['OneMax', 'FlipFlop', 'SixPeaks', 'ContinuousPeaks', 'Queens']
    logs = {}
    for i1, fitness in enumerate(fitnesses):
        logs[fitness_names[i1]] = {}
        problem_logs = logs[fitness_names[i1]]

        for size in [5, 10, 20, 40, 100]:
            problem_logs[size] = {}
            algorithm_logs = problem_logs[size]

            problem = mlrose.DiscreteOpt(length=size, fitness_fn=fitness, maximize=True)
            for i2, algorithm in enumerate(algorithms):
                algorithm_name = algorithm_names[i2]
                algorithm_logs[algorithm_name] = {}
                iterations_logs = algorithm_logs[algorithm_name]

                for max_iterations in [1, 5, 25, 125]:
                    print(algorithm_name,
                          'size:', size,
                          'max_iterations:', max_iterations,
                          algorithm_name)

                    parameter = {'problem': problem, 'random_state': 1, 'max_iters': max_iterations}
                    start_time = time.time()
                    best_state, best_fitness, _ = algorithm(**parameter)
                    total_time = time.time() - start_time
                    iterations_logs[max_iterations] = {'fitness': str(best_fitness),
                                                       'time': total_time}
    print()

    with open('past/part1_a_simple.json', 'w') as f:
        json.dump(logs, f)
        f.close()
