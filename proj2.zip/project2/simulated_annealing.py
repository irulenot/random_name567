import mlrose_hiive as mlrose
import matplotlib.pyplot as plt
import random
import json
import time

def generateTSP(dims, coord_count):
    coords_list = []
    for i in range(coord_count):
        point = (random.randint(0, dims[0]-1), random.randint(0, dims[1]-1))
        if point not in coords_list:
            coords_list.append(point)
    return coords_list

if __name__ == "__main__":
    algorithm = mlrose.simulated_annealing
    algorithm_name = 'simulated_annealing'
    algorithm_params = {'init_temp': [0.01, 0.5, 1, 10, 100],
                        'decay': [0.01, 0.1, 0.25, 0.5, 0.75, 1],
                        'min_temp': [0.01, 0.25, 0.5, 0.75, 0.99]}
    logs = {'TSP': {}}
    problem_logs = logs['TSP']
    size, layout = 100, 100000
    layout_input = (layout, layout)
    coords_list = generateTSP(layout_input, size)
    fitness_coords = mlrose.TravellingSales(coords=coords_list)
    problem = mlrose.TSPOpt(length = size, fitness_fn = fitness_coords, maximize=True)
    for param_name, params in algorithm_params.items():
        problem_logs[param_name] = {}
        param_logs = problem_logs[param_name]

        for param in params:
            hyper_parameter = {param_name: param}
            schedule = mlrose.GeomDecay(**hyper_parameter)
            parameter = {'problem': problem, 'random_state': 1, 'schedule': schedule}
            start_time = time.time()
            best_state, best_fitness, _ = algorithm( **parameter)
            total_time = time.time() - start_time
            param_logs[param] = {'fitness': str(best_fitness),
                                 'time': total_time}

    for problem, algorithms in logs.items():
        param_scores = {}
        param_times = {}
        param_names = list(algorithm_params.keys())
        param_idx = 0
        for algorithm, param_values in algorithms.items():
            param_scores[param_names[param_idx]] = []
            param_times[param_names[param_idx]] = []
            for param_values, values in param_values.items():
                score, time = values.values()
                param_scores[param_names[param_idx]].append(score)
                param_times[param_names[param_idx]].append(time)
            param_idx += 1

    fig, ax = plt.subplots(nrows=3, ncols=2, figsize=(15, 5))
    ax_idx = 0
    for name, values in algorithm_params.items():
        ax[ax_idx][0].plot(values, param_scores[name])
        ax[ax_idx][0].set_title(name + ' Scores')
        ax[ax_idx][0].set_xlabel(name)
        ax[ax_idx][0].set_ylabel('Fitness Score')
        ax[ax_idx][0].legend()

        ax[ax_idx][1].plot(values, param_times[name])
        ax[ax_idx][1].set_title(name + ' Times')
        ax[ax_idx][1].set_xlabel(name)
        ax[ax_idx][1].set_ylabel('Time')
        ax[ax_idx][1].legend()
        ax_idx += 1

    fig.tight_layout()
    plt.savefig('part1_graphs/' + algorithm_name + '_subplots.png')
    plt.clf()
