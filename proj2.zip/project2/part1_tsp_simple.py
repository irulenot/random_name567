import mlrose_hiive as mlrose
from tqdm import tqdm

import numpy as np
import random
import json
import time

def generateTSP(dims, coord_count):
    coords_list = []
    for i in range(coord_count):
        point = (random.randint(0, dims[0]-1), random.randint(0, dims[1]-1))
        if point not in coords_list:
            coords_list.append(point)
    return coords_list

if __name__ == "__main__":
    algorithms = [mlrose.random_hill_climb, mlrose.simulated_annealing,
                  mlrose.mimic, mlrose.genetic_alg]
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'mimic', 'genetic_alg']
    logs = {'TSP': {}}
    problem_logs = logs['TSP']
    for problem_param in [[5, 10],[10, 100],[20, 1000], [40, 10000], [100, 100000]]:
        size, layout = problem_param[0], problem_param[1]
        problem_logs[size] = {}
        algorithm_logs = problem_logs[size]

        layout_input = (layout, layout)
        coords_list = generateTSP(layout_input, size)
        fitness_coords = mlrose.TravellingSales(coords=coords_list)
        problem = mlrose.TSPOpt(length = size, fitness_fn = fitness_coords, maximize=True)
        for i2, algorithm in enumerate(algorithms):
            algorithm_name = algorithm_names[i2]
            algorithm_logs[algorithm_name] = {}
            iterations_logs = algorithm_logs[algorithm_name]

            for max_iterations in [1, 5, 25, 125]:
                print('TSP',
                      'layout:', layout,
                      'size:', size,
                      'max_iterations:', max_iterations,
                      algorithm_name)

                parameter = {'problem': problem, 'random_state': 1, 'max_iters': max_iterations}
                start_time = time.time()
                best_state, best_fitness, _ = algorithm(**parameter)
                total_time = time.time() - start_time
                iterations_logs[max_iterations] = {'fitness': str(best_fitness),
                                                  'time': total_time}
    print()

    with open('part1_tsp_simple.json', 'w') as f:
        json.dump(logs, f)
        f.close()
