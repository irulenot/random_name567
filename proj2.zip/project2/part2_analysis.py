import json
import matplotlib.pyplot as plt


if __name__ == "__main__":
    with open('part2_simple.json', 'r') as file:
        results = json.load(file)

    fitnesses, times = {}, {}
    for iteration, algorithms in results.items():
        for algorithm, fitness in algorithms.items():
            if algorithm not in fitnesses:
                fitnesses[algorithm], times[algorithm] = [], []
                times[algorithm] = []

            fitness, time = fitness.values()
            fitnesses[algorithm].append(fitness)
            times[algorithm].append(time)

    iterations = list(results.keys())
    for algorithm, score in fitnesses.items():
        plt.plot(iterations, score, label=algorithm)
    plt.title('Scores')
    plt.xlabel('Iterations')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.savefig('part2_graphs/Scores.png')
    plt.clf()

    for algorithm, times in times.items():
        plt.plot(iterations, times, label=algorithm)
    plt.title('Times')
    plt.xlabel('Iterations')
    plt.ylabel('Time')
    plt.legend()
    plt.savefig('part2_graphs/Times.png')
    plt.clf()