import pandas as pd
import numpy as np
import mlrose_hiive as mlrose
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import time
import json

# Accuracy
# Iterations
# Time

if __name__ == "__main__":
    DATA_PATH = 'data/'
    DATASET_DIR = 'stellar/'
    FILE_NAME = 'stellar.csv'
    dataset_name = DATASET_DIR[:-1]

    with open('results/' + dataset_name + '_Neural Net_results.json', 'r') as file:
        nn_results = json.load(file)
    best_idx = np.argmax(nn_results['test_score'])
    best_nn_params = {nn_results['param_names'][0]: nn_results['param1'][best_idx],
                      nn_results['param_names'][1]: nn_results['param2'][best_idx],
                      'random_state': 1}

    data = pd.read_csv(DATA_PATH + DATASET_DIR + FILE_NAME)
    for key in data.keys():
        le = LabelEncoder()
        if data[key].dtype == 'object':
            data[key] = le.fit_transform(data[key])
    data.dropna(inplace=True)
    if dataset_name == 'stellar':
        data = data.iloc[:5000]
        Y = pd.DataFrame(data, columns=['class'])
        X = data.drop(columns=['class', 'obj_ID'])
    X = StandardScaler().fit(X).transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X, Y, random_state=0, shuffle=True)
    y_train, y_test = y_train.values.ravel(), y_test.values.ravel()
    print('LEN:', str(len(X_train)))

    model_template = MLPClassifier(**best_nn_params).fit(X_train, y_train)
    np.random.seed(1)
    for i in range(len(model_template.coefs_)):
        model_template.coefs_[i] = np.random.rand(model_template.coefs_[i].shape[0],
                                                  model_template.coefs_[i].shape[1])
    init_state = []
    shapes = []
    for i in range(len(model_template.coefs_)):
        shapes.append(model_template.coefs_[i].shape)
        init_state += list(model_template.coefs_[i].flatten())
    def prediction_max(state):
        coeffs = []
        start = 0
        for shape in shapes:
            additional = shape[0] * shape[1]
            coeff = state[start:start+additional]
            coeff = np.array(coeff).reshape(shape)
            coeffs.append(coeff)
            start += additional

        model_template.coefs_ = coeffs
        pred = model_template.predict(X_train)
        return accuracy_score(y_train, pred)

    logs = {}
    algorithms = [mlrose.random_hill_climb, mlrose.simulated_annealing, mlrose.genetic_alg, MLPClassifier]
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'genetic_alg', 'back_prop']
    for iter in [1, 10, 100, 1000, 10000, 100000]:
        print(iter)
        logs[iter] = {}
        iter_logs = logs[iter]
        for i, algorithm in enumerate(algorithms):
            algorithm_name = algorithm_names[i]

            fitness_cust = mlrose.CustomFitness(prediction_max)
            problem = mlrose.ContinuousOpt(length=len(init_state), fitness_fn=fitness_cust, maximize=True,
                                           min_val=-10, max_val=10)
            if algorithm_name != 'back_prop':
                params = {'problem': problem, 'init_state': init_state.copy(),
                          'max_iters': iter, 'random_state': 1}
                if algorithm_name == 'random_hill_climb' or algorithm_name == 'simulated_annealing':
                    if algorithm_name == 'random_hill_climb':
                        params['restarts'] = 10
                    start_time = time.time()
                    best_state, accuracy, _ = algorithm(**params)
                    total_time = time.time() - start_time
                elif algorithm_name == 'genetic_alg':
                    del params['init_state']
                    start_time = time.time()
                    best_state, accuracy, _ = algorithm(**params)
                    total_time = time.time() - start_time
            elif algorithm_name == 'back_prop':
                best_nn_params['max_iter'] = iter
                model_bp = MLPClassifier(**best_nn_params)
                start_time = time.time()
                model_bp.fit(X_train, y_train)
                total_time = time.time() - start_time
                pred = model_bp.predict(X_train)
                accuracy = accuracy_score(y_train, pred)
            results = {'accuracy': accuracy,
                       'train_time': total_time}
            iter_logs[algorithm_name] = results
            print(algorithm_name, results)

    with open('part2_simple.json', 'w') as f:
        json.dump(logs, f)
        f.close()