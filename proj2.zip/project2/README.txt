Clone repository
https://github.com/irulenot/random_name567

Run part1_a_simple.py       # Generates json
Run part1_tsp_simple.py     # Generates json
Run part1_analysis.py       # Generates graphs for part 1
Run part2_simple.py         # Generates json
Run part2_analysis.py       # Generates graphs for part 2

Run genetic_algorithm.py    # genetic_algorithm graphs
Run mimic.py                # mimic graphs
Run

results/                    # NN param from part 1
data/                       # Dataset used in part 2
