import json
import matplotlib.pyplot as plt


if __name__ == "__main__":
    with open('part2_simple_nn.json', 'r') as file:
        results = json.load(file)

    fitnesses, times = {}, {}
    for iteration, algorithms in results.items():
        for algorithm, fitness in algorithms.items():
            if algorithm not in fitnesses:
                fitnesses[algorithm], times[algorithm] = [], []
                times[algorithm] = []

            fitness, time = fitness.values()
            fitnesses[algorithm].append(fitness)
            times[algorithm].append(time)

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(15, 5))

    iterations = list(results.keys())
    for algorithm, score in fitnesses.items():
        ax[0].plot(iterations, score, label=algorithm)
    ax[0].set_title('Scores')
    ax[0].set_xlabel('Iterations')
    ax[0].set_ylabel('Accuracy')
    ax[0].legend()

    for algorithm, times in times.items():
        ax[1].plot(iterations, times, label=algorithm)
    ax[1].set_title('Times')
    ax[1].set_xlabel('Iterations')
    ax[1].set_ylabel('Time')
    ax[1].legend()

    plt.savefig('part2_graphs/bp_subplots_nn.png')
    plt.clf()