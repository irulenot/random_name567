import mlrose_hiive as mlrose
from tqdm import tqdm

import numpy as np
import random
import json
import time

# 3 Optimization Problems
# 1: Genetic algorithm (TSP)
# 2: Simulated annealing (Continuous Peaks)
# 3: MIMIC (FlipFlop)

# Measurements
# Problem size
# Time to run
# Iterations
# Fitness score

if __name__ == "__main__":
    logs = {}
    algorithms = [mlrose.random_hill_climb, mlrose.simulated_annealing,
                  mlrose.mimic, mlrose.genetic_alg]
    fitnesses = [mlrose.OneMax(), mlrose.FlipFlop(), mlrose.SixPeaks(),
                 mlrose.ContinuousPeaks(), mlrose.Queens()]
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'mimic', 'genetic_alg']
    algorithm_params = {'random_hill_climb': {'restarts': [0, 5, 25]},
                        'simulated_annealing': {'schedule': [mlrose.GeomDecay(), mlrose.ArithDecay(), mlrose.ExpDecay()]},
                        'mimic': {'keep_pct': [0.01, 0.1, 0.5]},
                        'genetic_alg': {'mutation_prob': [0.01, 0.1, 0.5]}}
    fitness_names = ['OneMax', 'FlipFlop', 'SixPeaks', 'ContinuousPeaks', 'Queens']
    for i1, fitness in enumerate(fitnesses):
        logs[fitness_names[i1]] = {}
        fitness_logs = logs[fitness_names[i1]]

        for size in [5, 10, 20, 40]:
            fitness_logs[size] = {}
            size_logs = fitness_logs[size]

            problem = mlrose.DiscreteOpt(length=size, fitness_fn=fitness, maximize=True)
            for i2, algorithm in enumerate(algorithms):
                print(fitness_names[i1],
                      'size:', size,
                      algorithm_names[i2])
                size_logs[algorithm_names[i2]] = {}
                algorithm_logs = size_logs[algorithm_names[i2]]

                for max_iterations in [25, 125, 625]:
                    algorithm_logs[max_iterations] = {}
                    iterations_logs = algorithm_logs[max_iterations]

                    for max_attempts in [1, 10, 25]:
                        iterations_logs[max_attempts] = {}
                        attempt_logs = iterations_logs[max_attempts]

                        params = algorithm_params[algorithm_names[i2]]
                        key = list(params.keys())[0]
                        values = list(params.values())[0]
                        attempt_logs[key] = {}
                        param_logs = attempt_logs[key]
                        for value in values:
                            print('max_iterations', max_iterations,
                                  'max_attempts', max_attempts,
                                  key,value)

                            parameter = {'problem': problem, 'random_state':1, 'max_attempts': max_attempts,
                                         'max_iters': max_iterations, key: value}
                            start_time = time.time()
                            best_state, best_fitness, _ = algorithm(**parameter)
                            total_time = time.time() - start_time

                            algorithm_name = algorithm_names[i2]
                            if algorithm_name == 'simulated_annealing':
                                value = value.get_info__()['schedule_type']
                            param_logs[value] = {'fitness': str(best_fitness),
                                                 'time': total_time}
        print()

    with open('part1_a.json', 'w') as f:
        json.dump(logs, f)
        f.close()
