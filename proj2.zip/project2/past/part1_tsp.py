import mlrose_hiive as mlrose
from tqdm import tqdm

import numpy as np
import random
import json
import time

def generateTSP(dims, coord_count):
    coords_list = []
    for i in range(coord_count):
        point = (random.randint(0, dims[0]-1), random.randint(0, dims[1]-1))
        if point not in coords_list:
            coords_list.append(point)
    return coords_list

if __name__ == "__main__":
    logs = {}
    algorithms = [mlrose.random_hill_climb, mlrose.simulated_annealing,
                  mlrose.mimic, mlrose.genetic_alg]
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'mimic', 'genetic_alg']
    algorithm_params = {'random_hill_climb': {'restarts': [0, 5, 25]},
                        'simulated_annealing': {'schedule': [mlrose.GeomDecay(), mlrose.ArithDecay(), mlrose.ExpDecay()]},
                        'mimic': {'keep_pct': [0.01, 0.1, 0.5]},
                        'genetic_alg': {'mutation_prob': [0.01, 0.1, 0.5]}}

    for layout in [20, 100, 1000]:
        logs[layout] = {}
        layout_logs = logs[layout]

        for size in [5, 10, 20]:
            layout_logs[size] = {}
            size_logs = layout_logs[size]

            layout_input = (layout, layout)
            coords_list = generateTSP(layout_input, size)
            fitness_coords = mlrose.TravellingSales(coords=coords_list)
            problem = mlrose.TSPOpt(length = size, fitness_fn = fitness_coords, maximize=True)
            for i2, algorithm in enumerate(algorithms):
                print('TSP',
                      'layout:', layout,
                      'size:', size,
                      algorithm_names[i2])
                size_logs[algorithm_names[i2]] = {}
                algorithm_logs = size_logs[algorithm_names[i2]]

                for max_iterations in [25, 125, 625]:
                    algorithm_logs[max_iterations] = {}
                    iterations_logs = algorithm_logs[max_iterations]

                    for max_attempts in [1, 10, 25]:
                        iterations_logs[max_attempts] = {}
                        attempt_logs = iterations_logs[max_attempts]

                        params = algorithm_params[algorithm_names[i2]]
                        key = list(params.keys())[0]
                        values = list(params.values())[0]
                        attempt_logs[key] = {}
                        param_logs = attempt_logs[key]
                        for value in values:
                            print('max_iterations', max_iterations,
                                  'max_attempts', max_attempts,
                                  key,value)

                            parameter = {'problem': problem, 'random_state':1, 'max_attempts': max_attempts,
                                         'max_iters': max_iterations, key: value}
                            start_time = time.time()
                            best_state, best_fitness, _ = algorithm(**parameter)
                            total_time = time.time() - start_time

                            algorithm_name = algorithm_names[i2]
                            if algorithm_name == 'simulated_annealing':
                                value = value.get_info__()['schedule_type']
                            param_logs[value] = {'fitness': str(best_fitness),
                                                 'time': total_time}
        print()

    with open('part1_tsp.json', 'w') as f:
        json.dump(logs, f)
        f.close()
