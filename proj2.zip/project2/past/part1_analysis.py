import json

# Random hill climb: Restarts increase performance
# Simulated annealing: Geometric typically performs best, arithmetic worst
# MIMIC: 0.1 generally outperforms 0.01 and 0.5
#

if __name__ == "__main__":
    # Problem/size/alg/max_iterations/max_attempts/param
    with open('part1_a.json', 'r') as file:
        results_a = json.load(file)

    # Layout/size/alg/max_iterations/max_attempts/param
    with open('part1_tsp.json', 'r') as file:
        results_tsp = json.load(file)

    # 3x1 problems increasing in complexity
    # Each approach's best parameter
    algorithm_names = ['random_hill_climb', 'simulated_annealing', 'mimic', 'genetic_alg']
    performance = {}
    for key in results_a:
        problems = results_a[key]
        performance[key] = {}
        problem_performance = performance[key]
        for problem_size in problems:
            algorithms = problems[problem_size]
            problem_performance[problem_size] = {}
            size_performance = problem_performance[problem_size]
            for algorithm in algorithms:
                size_performance[algorithm] = {}
                algorithm_performance = size_performance[algorithm]
                algorithm_performance[algorithm] = {'fitness': 0, 'time': 0, 'params': None}

                max_iterations = algorithms[algorithm]
                for max_iteration in max_iterations:
                    max_attempts = max_iterations[max_iteration]
                    for max_attempt in max_attempts:
                        params = max_attempts[max_attempt]
                        for param in params:
                            param_values = params[param]
                            for parm_value in param_values:
                                fitness, time = param_values[parm_value].values()
                                fitness, time = float(fitness), float(time)
                                if fitness > algorithm_performance[algorithm]['fitness']:
                                    algorithm_performance[algorithm]['fitness'] = fitness
                                    algorithm_performance[algorithm]['time'] = time
                                    algorithm_performance[algorithm]['params'] = {'max_iterations': max_iteration,
                                                                            'max_attempts': max_attempt,
                                                                            param: parm_value}
                                elif fitness == algorithm_performance[algorithm]['fitness'] and time < algorithm_performance[algorithm]['time']:
                                    algorithm_performance[algorithm]['fitness'] = fitness
                                    algorithm_performance[algorithm]['time'] = time
                                    algorithm_performance[algorithm]['params'] = {'max_iterations': max_iteration,
                                                                                  'max_attempts': max_attempt,
                                                                                  param: parm_value}

    print('break')