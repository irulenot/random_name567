import json
import matplotlib.pyplot as plt


if __name__ == "__main__":
    with open('past/part1_a_simple.json', 'r') as file:
        results_a = json.load(file)
    with open('part1_tsp_simple.json', 'r') as file:
        results_tsp = json.load(file)

    results = results_a
    results['TSP'] = results_tsp['TSP']

    for problem, sizes in results.items():
        fitnesses, times125 = {}, {}
        times = {}

        for size, algorithms in sizes.items():
            for algorithm, iters in algorithms.items():
                if algorithm not in fitnesses:
                    fitnesses[algorithm], times125[algorithm] = [], []
                    times[algorithm] = []
                fitness, time125 = iters['125'].values()
                fitness = float(fitness)
                fitnesses[algorithm].append(fitness)
                times125[algorithm].append(time125)

                if size == list(sizes.keys())[-1]:
                    for iter, values in iters.items():
                        fitness, time = values.values()
                        times[algorithm].append(time)

        problem_sizes = list(sizes.keys())
        for algorithm, score in fitnesses.items():
            plt.plot(problem_sizes, score, label=algorithm)
        plt.title(problem)
        plt.xlabel('Problem Size')
        plt.ylabel('Fitness Score')
        plt.legend()
        plt.savefig('part1_graphs/' + problem + '_score.png')
        plt.clf()

        for algorithm, times125 in times125.items():
            plt.plot(problem_sizes, times125, label=algorithm)
        plt.title(problem)
        plt.xlabel('Problem Size')
        plt.ylabel('Times')
        plt.legend()
        plt.savefig('part1_graphs/' + problem + '_time.png')
        plt.clf()

        for algorithm, times in times.items():
            plt.plot(list(iters.keys()), times, label=algorithm)
        plt.title(problem)
        plt.xlabel('Iterations')
        plt.ylabel('Times')
        plt.legend()
        plt.savefig('part1_graphs/' + problem + '_iteration.png')
        plt.clf()