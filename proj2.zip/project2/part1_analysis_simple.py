import json
import matplotlib.pyplot as plt


if __name__ == "__main__":
    with open('past/part1_a_simple.json', 'r') as file:
        results_a = json.load(file)
    with open('part1_tsp_simple.json', 'r') as file:
        results_tsp = json.load(file)

    results = results_a
    results['TSP'] = results_tsp['TSP']

    for problem, sizes in results.items():
        fitnesses, times125 = {}, {}
        times = {}

        for size, algorithms in sizes.items():
            for algorithm, iters in algorithms.items():
                if algorithm not in fitnesses:
                    fitnesses[algorithm], times125[algorithm] = [], []
                    times[algorithm] = []
                fitness, time125 = iters['125'].values()
                fitness = float(fitness)
                fitnesses[algorithm].append(fitness)
                times125[algorithm].append(time125)

                if size == list(sizes.keys())[-1]:
                    for iter, values in iters.items():
                        fitness, time = values.values()
                        times[algorithm].append(time)

        fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(15, 5))

        problem_sizes = list(sizes.keys())
        for algorithm, score in fitnesses.items():
            ax[0].plot(problem_sizes, score, label=algorithm)
        ax[0].set_title(problem)
        ax[0].set_xlabel('Problem Size')
        ax[0].set_ylabel('Fitness Score')
        ax[0].legend()

        for algorithm, times125 in times125.items():
            ax[1].plot(problem_sizes, times125, label=algorithm)
        ax[1].set_title(problem)
        ax[1].set_xlabel('Problem Size')
        ax[1].set_ylabel('Times')
        ax[1].legend()

        for algorithm, times in times.items():
            ax[2].plot(list(iters.keys()), times, label=algorithm)
        ax[2].set_title(problem)
        ax[2].set_xlabel('Iterations')
        ax[2].set_ylabel('Times')
        ax[2].legend()

        plt.savefig('part1_graphs/' + problem + '_subplots.png')
        plt.clf()